jQuery.ajaxSetup({
    cache: false
});

$(document).ready(function () {
    $(window).bind('scroll', function (e) {
        parallaxScroll();
    });
    function parallaxScroll() {
        var scrolledY = $(window).scrollTop();
        if (scrolledY < 500) {
            $('#millky-gnb').css({
                'opacity': 1 - (scrolledY / 2000)
            });
        } else {
            $('#millky-gnb').css({
                'opacity': 0.75
            });
        }
    }
});

$(document).ready(function () {
    $('[data-toggle="offcanvas"]').click(function () {
        $('.row-offcanvas').toggleClass('active')
    });
});

// http://www.quirksmode.org/js/cookies.html
var CookieUtil = {
    createCookie: function (name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toGMTString();
        } else {
            expires = "";
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    },
    readCookie: function (name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1, c.length);
            }
            if (c.indexOf(nameEQ) == 0) {
                return c.substring(nameEQ.length, c.length);
            }
        }
        return null;
    },
    eraseCookie: function (name) {
        CookieUtil.createCookie(name, "", -1);
    }
};

// hide .backToTop first
$(".backToTop").hide();
$(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
        $('.backToTop').fadeIn();
    } else {
        $('.backToTop').fadeOut();
    }
});

$('.backToTop').click(function () {
    $("html, body").animate({
        scrollTop: 0
    }, 300);
    return false;
});

var millky = {};

